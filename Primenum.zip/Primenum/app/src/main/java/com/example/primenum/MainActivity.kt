package com.example.primenum

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    val updateText=1
    val handler=object:Handler(Looper.getMainLooper()){
        override fun handleMessage(msg: Message) {
           var standand=0
            when(msg.what){
                updateText ->{
                    val num=edittext.text.toString().toInt()
                    if(num<1) Toast.makeText(getApplicationContext(),"请输入正数",Toast.LENGTH_LONG).show()
                    if(num==1) Toast.makeText(getApplicationContext(),"1不参与讨论",Toast.LENGTH_LONG).show()
                    if(num>1){
                        for(i in 2..num/2){
                            standand = if(num%i==0){
                                0
                            } else 1
                        }
                    }
                    when(standand){
                        0-> Toast.makeText(getApplicationContext(),"该数字是素数",Toast.LENGTH_LONG).show()
                        1-> Toast.makeText(getApplicationContext(),"该数字不是素数",Toast.LENGTH_LONG).show()
                    }
                }

            }                }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button.setOnClickListener {
            thread {
                val msg = Message()
                msg.what = updateText
                handler.sendMessage(msg)
            }
        }
    }
}