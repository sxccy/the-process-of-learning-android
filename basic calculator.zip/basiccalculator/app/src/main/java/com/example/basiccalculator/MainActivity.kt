package com.example.basiccalculator

import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.widget.RadioButton
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        startbutton.setOnClickListener {
            val intent= Intent(this,MyService::class.java)
            intent.putExtra("firstnum",firstnum.text.toString())
            intent.putExtra("secondnum",secondnum.text.toString())
            findViewById<RadioButton>(group.checkedRadioButtonId)
            intent.putExtra("operation",findViewById<RadioButton>(group.checkedRadioButtonId).text.toString())
            //firstnum.setText(findViewById<RadioButton>(group.checkedRadioButtonId).text.toString())
            startService(intent)
        }
        endbutton.setOnClickListener {
            val intent=Intent(this,MyService::class.java)
            stopService(intent)
            val receiver=MyReceiver2()
            val filter=IntentFilter("zhenbuhuixiele")
            registerReceiver(receiver,filter)

        }
    }
}