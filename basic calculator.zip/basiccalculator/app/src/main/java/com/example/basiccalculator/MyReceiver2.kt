package com.example.basiccalculator

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class MyReceiver2: BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if ("zhenbuhuixiele" == intent.action) {
            var str=intent.getStringExtra("result")
            Toast.makeText(context, "结果是" + str, Toast.LENGTH_LONG).show()
        }
    }
}