package com.example.basiccalculator

import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
//import android.util.Log
import android.widget.Toast
//import kotlin.math.log

class MyService : Service() {

    override fun onBind(intent: Intent): IBinder {
        TODO("Return the communication channel to the service.")
    }

    override fun onCreate() {
        super.onCreate()
    }
    private var result:Double = 0.0
    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        val firstnum= intent.getStringExtra("firstnum")
        val operation=intent.getStringExtra("operation")
        val secondnum=intent.getStringExtra("secondnum")
        val a= firstnum?.toDouble()
        val b=secondnum?.toDouble()
        var re: Double? =null
        when(operation){
            "加" -> if (a != null) {
                re= a+ b!!
            }
            "减" -> if (a != null) {
                re=a- b!!
            }
            "乘" -> if (a != null) {
                re=a* b!!
            }
            "除" -> if (a != null) {
                re=a/ b!!
            }
        }
        if (re != null) {
            result=re
        }
//        val str=result.toString()
//        val intent=Intent("zhenbuhuixiele")
//        intent.putExtra("result",str)
//      //  intent.setAction("com.ljq.activity.CountService")
//        sendBroadcast(intent)
//        //Log.d("Myservice",str)
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onDestroy() {
        super.onDestroy()
        val str=result.toString()
        val intent=Intent("zhenbuhuixiele")
        intent.putExtra("result",str)
        //  intent.setAction("com.ljq.activity.CountService")
        sendBroadcast(intent)
    }
}